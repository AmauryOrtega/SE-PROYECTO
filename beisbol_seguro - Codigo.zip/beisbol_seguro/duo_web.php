<?php

/*
 * This file has been deprecated!
 *
 * Please consider using the namespaced class in src/Web.php
 */

require_once 'src/Web.php';

class_alias('Duo\Web', 'Duo');

?>
