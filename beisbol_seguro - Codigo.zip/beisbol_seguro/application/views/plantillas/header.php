<html>
    <head>
        <title>Beisbol Seguro</title>
    </head>
    <body>
        <h2><a href="<?php echo site_url();?>">Beisbol Seguro</a></h2>
        
        <h5><a href="<?php echo site_url('admin');?>">Admin</a></h5>
        <nav>
            <a href="<?php echo site_url('equipos');?>">Equipos</a> |
            <a href="<?php echo site_url('jugadores');?>">Jugadores</a> |
            <a href="<?php echo site_url('partidos');?>">Partidos</a> |
        </nav>
        <hr>
<!--Fin de header-->
