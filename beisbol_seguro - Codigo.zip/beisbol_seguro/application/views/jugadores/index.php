<style>
    table {
        width: auto;
    }
    table, th, td {
        border: 1px solid black;
        border-collapse: collapse;
    }
    th, td {
        padding: 5px;
    }
</style>

<nav>
    <a href="<?php echo site_url('jugadores/bateadores');?>">Bateadores</a> |
    <a href="<?php echo site_url('jugadores/lanzadores');?>">Lanzadores</a> |
<nav>
